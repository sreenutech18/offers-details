package com.citi.offers.beans;

import java.util.List;

import lombok.Data;

@Data
public class OffersRequest {
	
	private List<Product> products;

}
