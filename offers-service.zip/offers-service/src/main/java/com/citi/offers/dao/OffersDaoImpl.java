package com.citi.offers.dao;

public class OffersDaoImpl {

}
