package com.citi.offers.exception;

public class OffersRequestInvalidException {

}
