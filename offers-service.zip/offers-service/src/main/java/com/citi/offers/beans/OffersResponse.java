package com.citi.offers.beans;

import java.util.List;

import lombok.Data;

@Data
public class OffersResponse {

	private List<Offer> offers;
	
}
