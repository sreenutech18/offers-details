package com.citi.offers.util;

public class OffersUtil {

}
