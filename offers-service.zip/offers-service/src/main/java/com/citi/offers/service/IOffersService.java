package com.citi.offers.service;

public interface IOffersService {

}
