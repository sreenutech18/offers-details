package com.citi.offers.beans;

public class Product {
	
	private String pid;
	private String name;
	

}
