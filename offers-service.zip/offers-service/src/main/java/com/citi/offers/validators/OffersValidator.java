package com.citi.offers.validators;

public class OffersValidator {

}
