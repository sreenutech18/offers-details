package com.citi.offers.dao;

public interface IOffersDao {

}
